#MY REGISTER PAGE CODE
from tkinter import *

def reg():
    PINK = "#e2979c"
    RED = "#e7305b"
    GREEN = "#9bdeac"
    YELLOW = "#f7f5dd"
    FONT_NAME = "Courier"

    root = Tk()
    root.geometry("500x550")
    root.title("Registration form")
    root.config(bg="grey")

    label_0 = Label(root, text="Registration form", width=20, font=(FONT_NAME, 20), bg="grey")
    label_0.place(x=90, y=30)

    l1 = Label(root, text="Name:", width=10, font=("arial", 16), bg="grey")
    l1.place(x=0, y=120)
    e1 = Entry(root, width=25)
    e1.place(x=200, y=120)

    l2 = Label(root, text="Password:", width=13, font=("arial", 16), bg="grey")
    l2.place(x=0, y=365)
    e6 = Entry(root, show='*', width=25)
    e6.place(x=195, y=375)  # xand y for password entry.

    l3 = Label(root, text="Email:", width=10, font=("arial", 16), bg="grey")
    l3.place(x=0, y=160)
    e3 = Entry(root, width=25)
    e3.place(x=200, y=160)

    l4 = Label(root, text="Contact No:", width=13, font=("arial", 16), bg="grey")
    l4.place(x=0, y=200)
    e4 = Entry(root, width=25)
    e4.place(x=200, y=200)

    l5 = Label(root, text="Gender:", width=15, font=("arial", 16), bg="grey")
    l5.place(x=-30, y=240)
    var = IntVar()
    Radiobutton(root, text="Male", padx=5, variable=var, value=1, bg="grey").place(x=180, y=240)
    Radiobutton(root, text="Female", padx=10, variable=var, value=2, bg="grey").place(x=240, y=240)
    Radiobutton(root, text="Others", padx=15, variable=var, value=3, bg="grey").place(x=310, y=240)

    l10 = Label(root, text="Age gap:", width=15, font=("arial", 16), bg="grey")
    l10.place(x=-30, y=280)
    var1 = IntVar()
    Radiobutton(root, text="0-18", padx=5, variable=var1, value=1, width=5, bg="grey").place(x=175, y=285)
    Radiobutton(root, text="18-60", padx=10, variable=var1, value=2, width=5, bg="grey").place(x=240, y=285)
    Radiobutton(root, text="60+", padx=15, variable=var1, value=3, width=5, bg="grey").place(x=305, y=285)

    list_of_blood_grp = ("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")
    c = StringVar()
    droplist = OptionMenu(root, c, *list_of_blood_grp)
    droplist.config(width=15)
    c.set("B+")
    l2 = Label(root, text="Blood Group:", width=13, font=("arial", 16), bg="grey")
    l2.place(x=0, y=320)
    droplist.place(x=195, y=320)  # x and y for blood group.

    # l7 = Label(root, text="Re-Enter Password", width=15, font=("arial", 12))
    # l7.place(x=21, y=360)
    # e7 = Entry(root, show='*')
    # e7.place(x=200, y=360)

    l7 = Label(root, text="Address:", width=15, font=("arial", 16), bg="grey")
    l7.place(x=-20, y=420)
    textbox = Text(root, width=15, height=1, font=("Arial", 16))
    textbox.place(x=195, y=420)

    Button(root, text="Register", width=10, height=3).place(x=180, y=480)
    root.mainloop()


'''PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"

root = Tk()
root.geometry("500x550")
root.title("Registration form")
root.config(bg="grey")

label_0 = Label(root, text="Registration form",width=20,font=(FONT_NAME, 20),bg="grey")
label_0.place(x=90,y=30)

l1 = Label(root, text="Name:", width=10, font=("arial", 16),bg="grey")
l1.place(x=0, y=120)
e1 = Entry(root,width=25)
e1.place(x=200, y=120)

l2 = Label(root, text="Password:", width=13,font=("arial", 16),bg="grey")
l2.place(x=0, y=365)
e6 = Entry(root, show='*',width=25)
e6.place(x=195, y=375) # xand y for password entry.

l3 = Label(root, text="Email:", width=10, font=("arial", 16),bg="grey")
l3.place(x=0, y=160)
e3 = Entry(root,width=25)
e3.place(x=200, y=160)

l4 = Label(root, text="Contact No:", width=13, font=("arial", 16),bg="grey")
l4.place(x=0, y=200)
e4 = Entry(root,width=25)
e4.place(x=200, y=200)

l5 = Label(root, text="Gender:", width=15, font=("arial", 16),bg="grey")
l5.place(x=-30, y=240)
var = IntVar()
Radiobutton(root, text="Male", padx=5, variable=var, value=1,bg="grey").place(x=180, y=240)
Radiobutton(root, text="Female", padx=10, variable=var, value=2,bg="grey").place(x=240, y=240)
Radiobutton(root, text="Others", padx=15, variable=var, value=3,bg="grey").place(x=310, y=240)

l10 = Label(root, text="Age gap:", width=15, font=("arial", 16),bg="grey")
l10.place(x=-30, y=280)
var1 = IntVar()
Radiobutton(root, text="0-18", padx=5, variable=var1, value=1,width=5,bg="grey").place(x=175, y=285)
Radiobutton(root, text="18-60", padx=10, variable=var1, value=2,width=5,bg="grey").place(x=240, y=285)
Radiobutton(root, text="60+", padx=15, variable=var1, value=3,width=5,bg="grey").place(x=305, y=285)

list_of_blood_grp = ("A+","A-","B+","B-","O+","O-","AB+","AB-")
c = StringVar()
droplist = OptionMenu(root, c, *list_of_blood_grp)
droplist.config(width=15)
c.set("B+")
l2 = Label(root, text="Blood Group:", width=13, font=("arial", 16),bg="grey")
l2.place(x=0, y=320)
droplist.place(x=195, y=320) #x and y for blood group.



# l7 = Label(root, text="Re-Enter Password", width=15, font=("arial", 12))
# l7.place(x=21, y=360)
# e7 = Entry(root, show='*')
# e7.place(x=200, y=360)

l7 = Label(root, text="Address:", width=15, font=("arial", 16),bg="grey")
l7.place(x=-20, y=420)
textbox = Text(root, width=15, height=1, font=("Arial", 16))
textbox.place(x=195,y=420)

Button(root, text="Register", width=10,height=3).place(x=180, y=480)
root.mainloop()'''
