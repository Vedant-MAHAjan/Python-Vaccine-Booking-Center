from tkinter import ttk
from tkinter import *
#from PIL import Image, ImageTk
from PIL import Image, ImageTk

root = Tk()


# Hover
def changeOnHover(button, colorOnHover, colorOnLeave):
   # background on entering widget
   button.bind("<Enter>", func=lambda e: button.config(background=colorOnHover))

   # background color on leving widget
   button.bind("<Leave>", func=lambda e: button.config(background=colorOnLeave))

def booking_pg(root):
   root.title("Booking Window")
   root.geometry("1350x670+2+4")
   root.bg = ImageTk.PhotoImage(file="Booking.png")
   lb_bg = Label(root, image=root.bg)
   lb_bg.place(x=0, y=0, relwidth=1, relheight=1)

   register_lb1 = Label(root,text="Booking Page", font=("Open sans", 24, "bold"), bg="#545454", fg="white")
   register_lb1.place(x=165, y=150)

   #center choose (combobox
   center = Label(root, text="Center :", font=("arial", 17), bg="#545454", fg="white")
   center.place(x=130, y=250)
   combo_bg = ttk.Combobox(root, width=15, font=("arial", 14), state="readonly")
   combo_bg["values"] = ("Kandivali","Dahisar","Vasai")
   combo_bg.place(x=240, y=250)

   #test type radiobutton
   test = Label(root, text="Test :", font=("arial", 16), bg="#545454", fg="white")
   s = ttk.Style()  # Creating style element
   s.configure('Wild.TRadiobutton', background="#545454", foreground='white', font=("arial", 13))
   test.place(x=155, y=330)
   var = IntVar()
   r1 = ttk.Radiobutton(root, text="RT-PCR", variable=var, value=1, style='Wild.TRadiobutton')
   r1.place(x=238, y=333)
   r2 = ttk.Radiobutton(root, text="Antigen", variable=var, value=2, style='Wild.TRadiobutton')
   r2.place(x=345, y=333)
   r3 = ttk.Radiobutton(root, text="Rapid RT-PCR", variable=var, value=3, style='Wild.TRadiobutton')
   r3.place(x=440, y=333)

   # home test/center visit radiobutton
   test = Label(root, text="Sample Collection :", font=("arial", 17), bg="#545454", fg="white")
   s = ttk.Style()  # Creating style element
   s.configure('Wild.TRadiobutton', background="#545454", foreground='white', font=("arial", 13))
   test.place(x=17, y=410)
   var1 = IntVar()
   r1 = ttk.Radiobutton(root, text="Home",variable=var1, value=1, style='Wild.TRadiobutton')
   r1.place(x=238, y=414)
   r2 = ttk.Radiobutton(root, text="Center Visit", variable=var1, value=2, style='Wild.TRadiobutton')
   r2.place(x=320, y=414)

   #3 buttons
   bt1 = Button(root,text="Back",background="#CFCFCF", activebackground="#6BC145",font=("Arial", 13))
   bt1.place(x=120,y=500 ,height=42, width=100)
   changeOnHover(bt1, "#FF5757", "#CFCFCF")

   bt2 = Button(root, text="Book Test", background="#CFCFCF", activebackground="#6BC145",font=("Arial", 13))
   bt2.place(x=260, y=500, height=42, width=100)
   changeOnHover(bt2, "#6BC145", "#CFCFCF")

   bt3 = Button(root, text="Report", background="#CFCFCF", activebackground="#6BC145",font=("Arial", 13))
   bt3.place(x=185, y=575, height=42, width=100)
   changeOnHover(bt3, "#1ABAC2", "#CFCFCF")






   root.mainloop()
booking_pg(root)



